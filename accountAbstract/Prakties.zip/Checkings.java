public class Checkings extends Account
{
	public double over;
	public double with;
	public double alfa;
	
	public Checkings()
	{
		this("0",0,0);
	}
	
	public Checkings(String id, double balance, double over)
	{
		super(id, balance);
		setOver(over);
	
	}
	
	public void setOver(double over)
	{
		this.over = over;
	}
	
	public double getOver()
	{
		return over;
	}
	
	public void withdraw(double with)
	{
		super.setbalance(super.getbalance() - with);
		if(super.getbalance() < over)
		{
			System.out.println("Insuficiend funds");
			super.setbalance(super.getbalance() + with);
		}else
		{
			System.out.println("Sucsess");
		}
	}
	public double calculateInterest(int rental)
	{
		if(super.getbalance() < over)
		{
			alfa = (super.getbalance()*rental/100);
			alfa = alfa * 2;
			return alfa;
		}
		else if(super.getbalance() < 0)
		{
			alfa = (super.getbalance() * 4 * rental/100);
			return alfa;
		}
		else
		{
			alfa = (super.getbalance() * rental/100);
			return alfa;
		}
	}

	
	public String toString()
	{
		return (super.toString() + "\nBalance: " + super.getbalance() + "\nOverdraft: " + getOver());
	}
		public static void main(String[] args)
	{

		Checkings check = new Checkings("1",20000, -200);
		check.setOver(-50);
		check.withdraw(20060);
		System.out.println(check);
	}
}