public class Savings extends Account
{
	private double over;
	private double alfa;
	
	public Savings()
	{
		this("0",0,0);
	}
	
	public Savings(String id, double balance, /*String name*/ double over)
	{
		super(id, balance);
		setOver(over);
	}
	
	public void setOver(double over)
	{
		this.over = over;
	}
	
	public double getOver()
	{
		return over;
	}
	public void withdraw(double over)
	{
		super.setbalance(super.getbalance() - over);
		if(super.getbalance() < 0)
		{
			System.out.println("Insuficiend funds");
			super.setbalance(super.getbalance() + getOver());
		}else
		{
			System.out.println("Sucsess");
		}
	}
	public String toString()
	{
		return (super.toString() + "\nBalance: " + super.getbalance() + "\nWithdrawdraw: " + getOver());
	}
	
	public double calculateInterest(int rental)
	{
		if(super.getbalance() > 0)
		{
			alfa = (super.getbalance() * rental/100);
			return alfa;
		}
		return 0;
		
	}
	
	public static void main(String[] args)
	{
		Savings sav = new Savings("1",20000, -200);
		sav.setOver(1000000);
		sav.withdraw(sav.getOver());
		System.out.println(sav.toString());
	}
}