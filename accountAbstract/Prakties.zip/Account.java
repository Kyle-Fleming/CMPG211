import java.util.Date;

public abstract class Account
{
	private String id;
	private double balance;
	private double intrestrate;
	private Date datecreated;
	private String name;
	
	public Account(String id, double balance)
	{
		setid(id);
		setbalance(balance);
		//setName(name);
	}
	public Account()
	{
		this("0",0);
	}
	public void setid(String nid)
	{
		id = nid;
	}
	public void setbalance(double nbal)
	{
		balance = nbal;
	}
	public void setanaul(double nanaul)
	{
		intrestrate = nanaul;
	}
	public String getid()
	{
		return id;
	}
	public double getbalance()
	{
		return balance;
	}
	/*public double getanaul()
	{
		return intrestrate;
	}*/
	public String getdate()
	{
		datecreated = new Date();
		return datecreated.toString();
	}
	/*public double getMIR()
	{
		return (intrestrate / 12);
	}
	public double getMI()
	{
		return (balance * getMIR());
	}*/
	public String toString()
	{
		return ("Id:" + getid() + "\nBalance: " + getbalance()  + "\nDate: " + getdate() + "\nName: " + getName());
	}
	public void withdraw(double widraw)
	{
		balance = balance - widraw;
	}
	public void deposit(double depo)
	{
		balance = balance + depo;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getName()
	{
		return name;
	}
	public abstract double calculateInterest(int rental);
	
	
	public static void main(String[] args)
	{
		/*Account acc = new Account(1,20000, "AAAA");
		acc.withdraw(100);
		System.out.println("Balance: " + acc.getbalance());
		acc.deposit(200);
		System.out.println("Balance: " + acc.getbalance());
		System.out.println("Montly intrest rate:" + acc.getMIR() + "\nMothly intrest:" + acc.getMI());
		Account acc1 = new Account();	
		System.out.println(acc);*/
	}
}